                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1009659
Spider robot(quad robot, quadruped)-SG90 by regishsu is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

If you need get any support from me, would appreciate to make a donation:
http://paypal.me/RegisHsu

Instruction guide:
This is a quad robot that built by 3D printer and power by Arduino.  I also open the source( design by Sketchup) , you can put your great idea with it.   
The Instruction guide -   http://www.instructables.com/id/DIY-Spider-RobotQuad-robot-Quadruped/  
remote control - http://www.instructables.com/id/DIY-Spider-Robot-PART-II-Remote-control/

video:  
https://youtu.be/5hAmD499sJs  
https://youtu.be/ykIlCgIN2Bg  

and extra information: http://regishsu.blogspot.tw/2015/07/robot-quadruped-robot-re-design-3-round.html  
handmade PCB：  
http://regishsu.blogspot.tw/2015/09/robot-quadruped-robot-pcb-fail.html  
http://regishsu.blogspot.tw/2015/09/robot-quadruped-robot-pcb.html